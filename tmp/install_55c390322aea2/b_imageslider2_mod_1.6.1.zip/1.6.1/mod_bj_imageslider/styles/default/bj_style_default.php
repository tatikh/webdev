<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

?>
<script type="text/javascript">
//<![CDATA[
/*
var cssText = '#BJ_ImageSlider_JQ { visibility: hidden; }';var ref = document.createElement('style');
ref.setAttribute("rel", "stylesheet");
ref.setAttribute("type", "text/css");
document.getElementsByTagName("head")[0].appendChild(ref);
if(!!(window.attachEvent && !window.opera)) ref.styleSheet.cssText = cssText ;//this one's for ie
else ref.appendChild(document.createTextNode(cssText ));
*/
// ]]>
</script>