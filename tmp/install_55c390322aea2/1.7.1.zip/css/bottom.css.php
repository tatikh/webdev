<ul>
	<li>
		<div align="center">© 2012 BJ Jupiter Demo Live Site</div>
		<?php echo JText::_('TPL_JUPITER_POWERED_BY');?> <a href="http://www.joomla.org/">Joomla!&#174;</a>
		<div class="clearer"><!-- --></div>
		<div class="design"><?php echo JText::_('TPL_JUPITER_JOOMLA_TEMPLATE_BY');?> <a href="http://byjoomla.com" target="_blank" title="<?php echo JText::_('TPL_VENUS_JOOMLA_TEMPLATE_BY_BYJOOMLA');?>">ByJoomla.com</a>.</div>
	</li>
	<li>
	<?php echo JText::_('TPL_JUPITER_VALID');?>:&nbsp;&nbsp;&nbsp;<a href="http://validator.w3.org/check?uri=referer" title="<?php echo JText::_('TPL_VENUS_VALID');?> XHTML" target="_blank" class="xhtml">xhtml</a>
	<?php echo JText::_('TPL_JUPITER_VALID');?>:&nbsp;&nbsp;&nbsp;<a title="<?php echo JText::_('TPL_JUPITER_VALID');?> CSS" target="_blank" href="http://jigsaw.w3.org/css-validator/" class="css">css</a>
	</li>
</ul>
