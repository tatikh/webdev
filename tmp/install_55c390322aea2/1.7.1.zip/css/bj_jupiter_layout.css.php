<style type="text/css">
#BJ_MainMenu{top:<?php echo $layout_fix_mainmenu_top;?>px}
<?php 
if(endsWith($_tempWidth,'px')) $_tempWidth = substr($_tempWidth,0,strlen($_tempWidth) - 2);
if(endsWith($_tempLeftCol,'px')) $_tempLeftCol = substr($_tempLeftCol,0,strlen($_tempLeftCol) - 2);
if(endsWith($_tempRightCol,'px')) $_tempRightCol = substr($_tempRightCol,0,strlen($_tempRightCol) - 2);
?>
.inner{width:<?php echo $_tempWidth;?>px;}
#BJ_Left_Col{width:<?php echo $_tempLeftCol;?>px;}
#BJ_Right{width:<?php echo $_tempRightCol;?>px;}
#BJ_Headline .jupiter-headline{width:<?php echo $_tempWidth;?>px;}
.jupiter-headline .text .content{width:<?php echo ($_tempWidth - 160);?>px;}

#BJ_User1 .column{width:<?php echo ($col1_count > 0) ? (100/$col1_count) : 0;?>%}
#BJ_User2 .column{width:<?php echo ($col2_count > 0) ? (100/$col2_count) : 0;?>%}
#BJ_User2 input.inputbox{width:<?php echo ($col2_count > 0) ? $_tempWidth/$col2_count * 0.9 - 10 : 0;?>px}
#BJ_User3 .column{width:<?php echo ($col3_count > 0) ? (100/$col3_count) : 0;?>%}
#BJ_User3 input.inputbox{width:<?php echo ($col3_count > 0) ? $_tempWidth/$col3_count * 0.9 - 10 : 0;?>px}

<?php if($left & $right){?>
#BJ_Right_Col{width:<?php echo $_tempWidth - $_tempLeftCol - 29;?>px}
#BJ_Main{width:<?php echo $_tempWidth - $_tempLeftCol - $_tempRightCol - 60;?>px;}
#BJ_Component .blog{width:<?php echo $_tempWidth - $_tempRightCol - $_tempRightCol - 100;?>px;}
<?php } else if(!$left && $right){?>
#BJ_Right_Col{width:<?php echo $_tempWidth;?>px;margin-left:0}
#BJ_Main{width:<?php echo $_tempWidth - $_tempRightCol - 31;?>px;}
#BJ_Component .blog{width:<?php echo $_tempWidth - $_tempRightCol - 71;?>px;}
#BJ_Component .homepage .items-row{width:<?php echo $_tempWidth - $_tempRightCol - 31;?>px;}
<?php } else if($left && !$right){?>
#BJ_Right_Col{width:<?php echo $_tempWidth - $_tempLeftCol - 18;?>px}
#BJ_Main{width:100%}
<?php } else {?>
#BJ_Right_Col{width:<?php echo $_tempWidth;?>px;margin-left:0}
#BJ_Main{width:<?php echo $_tempWidth;?>px;}
#BJ_Main .blog{width:<?php echo $_tempWidth - 40;?>px;}
<?php }?>
</style>