/* 
	Get Element of a DOM Node by its class name
*/
function getElementsByClassName(node, classname)
{
    var a = [];
    var re = new RegExp('\\b' + classname + '\\b');
    var els = node.getElementsByTagName("*");
    for(var i=0,j=els.length; i<j; i++)
        if(re.test(els[i].className))a.push(els[i]);
    return a;
}

var defaultFontSize = 12;
var currentFontSize = defaultFontSize;

function changeFontSize(sizeDifference){
	if(sizeDifference == 0) {
		currentFontSize = defaultFontSize;
	} else {
		currentFontSize = parseInt(currentFontSize) + parseInt(sizeDifference);
		if(currentFontSize > 15){
			currentFontSize = 15;
		}else if(currentFontSize < 10){
			currentFontSize = 10;
		}
	}

	setFontSize(currentFontSize);
};

function setFontSize(fontSize){
	document.body.style.fontSize = fontSize + 'px';
};

/* == BJ OBJECT UTILITIES */
if (typeof window.bj =='undefined') window.bj = new Object();
bj.version = "0.0.1";

/*
 * Get position of an element, relative to document top-left corner
 * el: jQuery object
 * return {top,left}
 */
bj.getPos = function(el) {
	if(el != null)
	{
		var offset = el.offset();
		return {'left':offset.left,'top':offset.top};
	}
};

/*
 * Check if mouse if over an element
 * el: jQuery object
 */
bj.mouseIsOver = function(el,x,y) {
	var pos = bj.getPos(el);
	var top = pos.top;
	var left = pos.left;
	return x >= left && x <= left+el.width() && y >= top && y <= top+el.height();
};
/* == END CONSTRUCTING BJ OBJECT == */

bj.getTextNode = function(el){
	return el.contents()
		.filter(function() {
		return this.nodeType == 3;
	});
};

jQuery().ready(function($){
	/* ========= Re-position Dropdown Menu ================= */	
	$("#BJ_MainMenu").css({right:($(document).width()-_TEMP_WIDTH)/2});
	/* ========= HACK module CSS =========================== */	
	var textnodes = bj.getTextNode($(".pagination"));
		textnodes.each(function(){$(this).wrap("<span class='hide'>");});
	$(".module").each(function(){
		var h3 = $("h3",$(this));
		
		var content_height = $("div:eq(2)",$(this)).innerHeight();
		
		var top_padding = $(this).css('padding-top').replace("px", "");
		
		var bottom_padding=$("div:eq(0)",$(this)).css('padding-bottom').replace("px", "");		
		var margin = 0;
		if(h3.css('marginTop')!= null && h3.css('marginBottom')!= null)
		{
			margin = parseInt(h3.css('marginTop').replace("px",""))+parseInt(h3.css('marginBottom').replace("px",""));
		}
		var extraHeight = 0;
		if($(".menu",$(this)).length > 0){
			extraHeight = -15;
		}
		if(!h3.html()){
			extraHeight = 15;
			//$("div.bjmod-content",$(this)).css("top","3px");
		}
		content_height = content_height-top_padding-bottom_padding+h3.innerHeight()-margin + extraHeight;
		$("div.i:eq(1)",$(this)).css('height',content_height+'px');
		
		// show module
		$(this).css({left:0});
	});

	$("div.bjmod-style-4,div.bjmod-style-3,div.bjmod-style-2,div.bjmod-style-1").each(function(){
		var cls = $(this).attr("class");
		cls = cls.replace("bjmod-style-4","").replace("bjmod-style-3","").replace("bjmod-style-2","").replace("bjmod-style-1","").replace("module","");
		if(jQuery.trim(cls) != "")
			$("div:eq(0)",$(this)).attr("class","i " + cls);
	});
	
	/* ========= END HACK module CSS ======================== */

	$(document).bind('click',hideCollapsibleContent);
	var timeout = true;
	$(".collapsible .title").each(function(index,value){
		$(this).mouseover(function(){
			if(_TOPMOD_HOVER){
				var parnt = $(this).parent();
				
				// trigger mouse out on other title
				$(".collapsible .title:lt("+index+"),.collapsible .title:gt("+index+")").trigger("mouseout");
				
				var content = parnt.children(".content");
				if(!parnt.hasClass("mouseover")){
					content.slideUp(1,function(){
						parnt.addClass("mouseover");
						timeout = false;
						content.slideDown();
					});
				}
			}
		}).mouseout(function(evt){
			if(_TOPMOD_HOVER){
				if(!bj.mouseIsOver($(".content",$(this).parent()),evt.pageX,evt.pageY)){
					var parnt = $(this).parent();
					var content = parnt.children(".content");
					timeout = true;
					content.slideUp(400,function(){
						if(timeout){
							parnt.removeClass("mouseover");
						}
					});
				}
			}
		}).click(function(){
			var content = $(this).parent().children(".content");
			// hide other content
			$(this).parent().siblings().children(".content").addClass("float-hide");
			if(content.hasClass("float-hide"))
			{
				content.slideUp(0);
				content.removeClass("float-hide");
				content.slideDown();
			} 
			else 
			{
				content.slideUp();
				content.addClass("float-hide");
			}
			return false;
		});
	});
	/* ========= fix typo ===================== */
	$("span.typo-home,span.typo-plus,span.typo-minus,span.typo-plus,span.typo-plus2,span.typo-minus2,span.typo-delete,span.typo-accept,span.typo-warning,span.typo-heart,span.typo-mail,span.typo-star,span.typo-thumbup,span.typo-thumbdown,span.typo-down,span.typo-up,span.typo-sticker,span.typo-zoom,span.typo-refresh,span.typo-earth,span.typo-key,span.typo-lock,span.typo-rss,span.typo-folder,span.typo-calendar,span.typo-pencil,span.typo-cart,span.typo-recycle,span.typo-dialog,span.typo-download,span.typo-user,span.typo-user2, span.typo-search").html("&nbsp;");$("span.icon").html("&nbsp;");
	$(".jupiter-textbox-1").each(function(){
		var html =$(this).html();
		$(this).html("<div class=\"bg\">"+html+"</div>");
	});
	
	$(".jupiter-textbox-2").each(function(){
		$("div.blue,div.brown,div.purple,div.green,div.orange,div.red",$(this)).wrapInner("<div><div><div><div><div><div><div><div><div class=\"content\"></div></div></div></div></div></div></div></div></div>");
	});
	
	$(".jupiter-number-round,.jupiter-number-square").each(function(){
		var num = $(".number",$(this)).html();
		$(".number",$(this)).html("<span class=\"shadow\">"+num+"</span>" + "<span class=\"front\">"+num+"</span>");
	});
	
	$("a.button-2").each(function(){
		var cls = $(this).attr("class");
		cls = cls.replace("button-2","").trim();
		var html = $(this).html();
		$(this).wrap("<div class=\"button-2-"+cls+"\"></div>");
		$(this).html("<span class=\"left\"><!-- --></span><span class=\"shadow\">"+html+"<span class=\"front\">"+html+"</span></span><span class=\"right\"><!-- --></span>");
		
		$(this).parent().parent().addClass("block").append("<div class=\"clearer\"></div>");
	});
	$("a.button-1").each(function(){
		var cls = $(this).attr("class");
		cls = cls.replace("button-1","").trim();
		$(this).wrap("<div class=\"button-1-"+cls+"\"></div>");
		$(this).parent().parent().addClass("block").append("<div class=\"clearer\"></div>");
	});
	
	$("#BJ_Bottoms .module").each(function(){
		$(".article_separator:last",$(this)).removeClass("article_separator");
	});
	
	// pre-load any images in CSS => This let to a dramatical reduction in loading speed in IE
	//jQuery.preloadCssImages();
});

function hideCollapsibleContent(evt)
{
	var content = jQuery(".collapsible .content");
	if(content != null){
		content.each(function(){
			if(!_TOPMOD_HOVER){
				if(!jQuery(this).hasClass("float-hide") && !bj.mouseIsOver(jQuery(this),evt.pageX,evt.pageY))
				{
					jQuery(this).addClass("float-hide");
				}
			} else {
				if(!bj.mouseIsOver(jQuery(this),evt.pageX,evt.pageY))
				{
					jQuery(this).parent().removeClass("mouseover");
				}
			}
		});
	}
}

jQuery.preloadCssImages = function(){
        var allImgs = [];//new array for all the image urls  
        var k = 0; //iterator for adding images
        var sheets = document.styleSheets;//array of stylesheets
        
        for(var i = 0; i<sheets .length; i++){//loop through each stylesheet
                var cssPile = '';//create large string of all css rules in sheet
                var csshref = (sheets[i].href) ? sheets[i].href : 'window.location.href';
                var baseURLarr = csshref.split('/');//split href at / to make array
                baseURLarr.pop();//remove file path from baseURL array
                var baseURL = baseURLarr.join('/');//create base url for the images in this sheet (css file's dir)
                if(baseURL!="") baseURL+='/'; //tack on a / if needed
                if(document.styleSheets[i].cssRules){//w3
                        var thisSheetRules = document.styleSheets[i].cssRules; //w3
                        for(var j = 0; j<thisSheetRules.length; j++){
                                cssPile+= thisSheetRules[j].cssText;
                        }
                }
                else {
                        cssPile+= document.styleSheets[i].cssText;
                }
                
                //parse cssPile for image urls and load them into the DOM
                var imgUrls = cssPile.match(/[^\(]+\.(gif|jpg|jpeg|png)/g);//reg ex to get a string of between a "(" and a ".filename"
                if(imgUrls != null && imgUrls.length>0 && imgUrls != ''){//loop array
                        var arr = jQuery.makeArray(imgUrls);//create array from regex obj        
                        jQuery(arr).each(function(){
                                allImgs[k] = new Image(); //new img obj
                                allImgs[k].src = (this[0] == '/' || this.match('http://')) ? this : baseURL + this;     //set src either absolute or rel to css dir
                                k++;
                        });
                }
        }//loop
        return allImgs;
}