<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/* === Get Template parameters ================================== */
$template_color = $this->params->get("templateColor","blue");

$_align = $this->params->get("textalign","LTR");
$_logoPath = $this->params->get("logoPath","");
$_logoLink = $this->params->get("logoLink","");
$_logoSlogan = $this->params->get("logoSlogan","BJ Jupiter");
$_tempWidth = $this->params->get("templateWidth",'960px');
$_tempLeftCol= $this->params->get("leftWidth",'202px');
$_tempRightCol = $this->params->get("rightWidth",'202px');
$_usersALayout = $this->params->get("usersALayout",'0');
$_user1w = $this->params->get("user1w",'25%');
$_user2w = $this->params->get("user2w",'25%');
$_user3w = $this->params->get("user3w",'25%');
$_user4w = $this->params->get("user4w",'25%');
$_usersBLayout = $this->params->get("usersBLayout",'0');
$_user5w = $this->params->get("user5w",'25%');
$_user6w = $this->params->get("user6w",'25%');
$_user7w = $this->params->get("user7w",'25%');
$_user8w = $this->params->get("user8w",'25%');
$_usersCLayout = $this->params->get("usersCLayout",'0');
$_user9w = $this->params->get("user9w",'25%');
$_user10w = $this->params->get("user10w",'25%');
$_user11w = $this->params->get("user11w",'25%');
$_user12w = $this->params->get("user12w",'25%');
$layout_fix_mainmenu_top = $this->params->get("layout_fix_mainmenu_top",'0');


$comt = JRequest::getVar('option','');

/* === End parameters =========================================== */
$template_name = 'bj_jupiter';
define( '_TEMPLATE_PATH', JPATH_BASE . DS . 'templates' . DS .$template_name);
define('_TEMPLATE_URL',JURI::base().'templates/'.$template_name);
include_once(_TEMPLATE_PATH.'/func/bj_func.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
<?php
	$col1_count = 0;$col2_count = 0;$col2_count = 0;
	$header = 0;
	$left = 0;
	$right = 0;
	$headline = 0;
	$user1 = 0;$user2 = 0;$user3 = 0;$user4 = 0;$user5 = 0;
	$user6 = 0;$user7 = 0;$user8 = 0;$user9 = 0;$user10 = 0;$user11 = 0;$user12 = 0;
	$top = 0;
	$advert1 = 0;
	$toolbar = 1;		
	if($this->countModules('user1')) { $user1 = 1;$col1_count++;}
	if($this->countModules('user2')) { $user2 = 1;$col1_count++;}
	if($this->countModules('user3')) { $user3 = 1;$col1_count++;}
	if($this->countModules('user4')) { $user4 = 1;$col1_count++;}
	if($this->countModules('user5')) { $user5 = 1;$col2_count++;}
	if($this->countModules('user6')) { $user6 = 1;$col2_count++;}
	if($this->countModules('user7')) { $user7 = 1;$col2_count++;}
	if($this->countModules('user8')) { $user8 = 1;$col2_count++;}
	if($this->countModules('user9')) { $user9 = 1;$col3_count++;}
	if($this->countModules('user10')) { $user10 = 1;$col3_count++;}
	if($this->countModules('user11')) { $user11 = 1;$col3_count++;}
	if($this->countModules('user12')) { $user12 = 1;$col3_count++;}
	if($this->countModules('left')) { $left = 1;}
	if($this->countModules('right')) { $right = 1;}
	if($this->countModules('cpanel')) { $cpanel = 1;}
	if($this->countModules('advert1')) { $advert1 = 1;}
	if($this->countModules('toolbar')) { $toolbar = 1;}	
	if($this->countModules('header')){$header=1;}	
	if($this->countModules('top')){$top=1;}	
	if($this->countModules('headline')){$headline=1;}
	if($this->countModules('banner')){$banner=1;}
?>
<?php 
$theme_name = 'theme1';
$file = JPATH_BASE.DS.'components'.DS.'com_bjthemes'.DS.'bj_themeloader.php';
$load_theme_result = false;

if(!$load_theme_result){
?>
<script type="text/javascript" src="<?php echo _TEMPLATE_URL?>/func/jquery-1.4.2.js"></script>
<script type="text/javascript">
  jQuery.noConflict();
  var _TEMPLATE_URL = '<?php echo _TEMPLATE_URL ?>';
  var _TEMP_WIDTH = <?php if(strlen($_tempWidth) > 2) echo substr($_tempWidth,0,strlen($_tempWidth)-2); else echo 960;?>
</script>
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/template_css.css" type="text/css" />
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/bj_dropdownmenu.css" type="text/css" />
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/<?php echo $template_color; ?>.css" type="text/css" />
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/final.css" type="text/css" />
<?php if($_align == "RTL"){?>
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/rtl.css" type="text/css" />
<?php }?>
<?php include _TEMPLATE_PATH.'/css/bj_jupiter_layout.css.php';?>
<!--[if IE]>
<style type="text/css">
div.componentheading .left{margin-top:-7px}

/* FIX COLOR IN IE */
.jupiter-textbox-2 div.blue{background:#002545;}
.jupiter-textbox-2 div.green{background:#173100}
.jupiter-textbox-2 div.purple{background:#321039}
.jupiter-textbox-2 div.orange{background:#D16500}
.jupiter-textbox-2 div.brown{background:#2F261B}
.jupiter-textbox-2 div.red{background:#610004}
</style>
<![endif]-->
<!--[if IE 7]>
<style type="text/css">
#BJ_MainMenu{top:<?php echo $layout_fix_mainmenu_top+3;?>px}
input.button,button.button{line-height:28px;padding:0}
<?php if($left == 0){?>
#BJ_MainBody{margin:0}
<?php }?>
div.bjmod-style-2 h3 .bjmod-head-r,div.bjmod-style-3 h3 .bjmod-head-r,div.bjmod-style-2 h4 .bjmod-head-r,div.bjmod-style-3 h4 .bjmod-head-r,div.bjmod-style-2 h5 .bjmod-head-r,div.bjmod-style-3 h5 .bjmod-head-r{margin:-19px -7px 0 0;}
div.componentheading .left{margin-top:-7px}
div.componentheading .right{margin-top:-49px}
.button-1-,.button-1-blue,.button-1-green,.button-1-orange,.button-1-purple,.button-1-brown,.button-1-red{padding:0;}
.button-2-,.button-2-blue,.button-2-green,.button-2-orange,.button-2-purple,.button-2-brown,.button-2-red{padding:9px 0}
a.button-2 .front{top:10px}
</style>
<![endif]-->
<?php }?>
</head>
<body>
<center>
<?php if($toolbar){?>
<div id="BJ_MainMenu" class="dropdown">
	<div class="MainMenu-inner1">
		<div class="MainMenu-inner2">
			<jdoc:include type="modules" name="toolbar" style="raw" />
		</div>
	</div>
</div>       
<?php }?>
<div id="BJ_Logo_Search">
<div class="inner">
			<div id="BJ_Logo">
			<?php if(!$header) {?>
				<?php if($_logoLink){?>
				<a href="<?php echo  $_logoLink;?>" title="<? echo $_logoSlogan;?>">
				<?php }?>
					<?php 
					if($_logoPath == ''){
						switch($template_color){
						case 'blue': $src = _TEMPLATE_URL . '/images/bj-logo-2.png';break;
						case 'pink': $src = _TEMPLATE_URL . '/images/bj-logo-3.png';break;
						default: $src = _TEMPLATE_URL . '/images/bj-logo-1.png';break;
						}
					} else $src = $_logoPath;
					?>
					<img src="<?php echo  $src; ?>" alt="<? echo $_logoSlogan;?>"/>
				<?php if($_logoLink){?>				
				</a>
				<?php }?>
			<?php } else {?>
			<jdoc:include type="modules" name="header" style="raw" />
			<?php }?>
			</div>			
	</div>  
</div>

         <?php if($advert1){?>
		<div id="BJ_Jupiter_SlideShow">
        <div class="inner"><center>
			<jdoc:include type="modules" name="advert1" style="raw" /></center>
		</div>
        </div>
		<?php }?>
        <?php if($headline){?>
			<div id="BJ_Headline">
             <div class="inner">
				<jdoc:include type="modules" name="headline" style="raw" />
                </div>
			</div>
			<div class="clearer"><!-- --></div>
		<?php }?>
<div id="BJ_MainPage">	
	<div class="inner">
		<div class="clearer"><!-- --></div>		
        	<?php if($user1 || $user2 || $user3 || $user4){?>
		<center>
			<div id="BJ_User1" class="out_module">        
				<?php if($user1){?>
				<div class="column" id="user1">
					<jdoc:include type="modules" name="user1" style="bj_default" />
				</div>
				<?php }?>
				<?php if($user2){?>
				<div class="column" id="user2">
					<jdoc:include type="modules" name="user2" style="bj_default" />
				</div>
				<?php }?>
				<?php if($user3){?>
				<div class="column" id="user3">
					<jdoc:include type="modules" name="user3" style="bj_default" />
				</div>
				<?php }?>
				<?php if($user4){?>
				<div class="column" id="user4">
					<jdoc:include type="modules" name="user4" style="bj_default" />
				</div>
				<?php }?>
				<div class="clearer"><!-- --></div>
			</div>
		</center>
		<?php }?>        
		<div id="BJ_MainBody">
			<?php if($left){?><div id="BJ_Left_Col"><jdoc:include type="modules" name="left" style="bj_default" /></div><?php }?>
			<div id="BJ_Right_Col">
				<div id="BJ_Main">
				
					<?php if($top){?>
					<div id="BJ_Top" class="out_module">
						<jdoc:include type="modules" name="top" style="xhtml" />						
					</div>
					<div class="clearer"><!-- --></div>
					<?php }?>
					<div id="BJ_Component">
						<jdoc:include type="message" />
						<?php require_once(dirname(__FILE__) .'/css/system.php'); ?>
						<jdoc:include type="component" />
					</div>
					<div class="clearer"><!-- --></div>
					<?php if($banner){?>
					<div id="BJ_Banner" class="out_module">
						<jdoc:include type="modules" name="banner" style="xhtml" />
					</div>
					<div class="clearer"><!-- --></div>
					<?php }?>
				</div>
				<?php if($right){?>
				<div id="BJ_Right">
					<jdoc:include type="modules" name="right" style="bj_default" />
				</div>
				<?php }?>
				<div class="clearer"><!-- --></div>
			</div>
			<div class="clearer"><!-- --></div>
		</div>
	</div>
</div>
<div class="clearer"><!-- --></div>
<div id="BJ_BottomPage" class="out_module">
	<div class="clearer"><!-- --></div>
	<?php if($user5 || $user6 || $user7 || $user8){?>
        <div id="BJ_User2">
			<div id="BJ_User2-inner">
				<div class="inner lighter">
					<?php if($user5){?>
					<div class="column" id="user5">
						<jdoc:include type="modules" name="user5" style="bj_default" />
					</div>
					<?php }?>
					<?php if($user6){?>
					<div class="column" id="user6">
						<jdoc:include type="modules" name="user6" style="bj_default" />
					</div>
					<?php }?>
					<?php if($user7){?>
					<div class="column" id="user7">
						<jdoc:include type="modules" name="user7" style="bj_default" />
					</div>
					<?php }?>
					<?php if($user8){?>
					<div class="column" id="user8">
						<jdoc:include type="modules" name="user8" style="bj_default" />
					</div>
					<?php }?>
					<div class="clearer"><!-- --></div>
				</div>
			</div>
		</div>
		<?php }?>
        <?php if($user9 || $user10 || $user11 || $user12){?>
			<div id="BJ_User3">
				<div class="inner lighter">
					<?php if($user9){?>
					<div class="column" id="user9">
						<jdoc:include type="modules" name="user9" style="bj_default" />
					</div>
					<?php }?>
					<?php if($user10){?>
					<div class="column" id="user10">
						<jdoc:include type="modules" name="user10" style="bj_default" />
					</div>
					<?php }?>
					<?php if($user11){?>
					<div class="column" id="user11">
						<jdoc:include type="modules" name="user11" style="bj_default" />
					</div>
					<?php }?>
					<?php if($user12){?>
					<div class="column" id="user12">
						<jdoc:include type="modules" name="user12" style="bj_default" />
					</div>
					<?php }?>
					<div class="clearer"><!-- --></div>
				</div>
			</div>
		<?php }?>      
	<div id="BJ_Bottoms">		
		<div class="inner">
			<div class="clearer"><!-- --></div>
			<div id="BJ_Footer">
				<div id="BJ_Foot" class="list-nobg">
					<?php  include_once(_TEMPLATE_PATH.'/css/bottom.css.php'); ?>
				</div>
				<div id="BJ_Foot_Menu">
					<jdoc:include type="modules" name="footer" style="raw" />
				</div>
				<div class="clearer"><!-- --></div>
			</div>
			<div class="clearer"><!-- --></div>
		</div>
	</div>
	<div class="clearer"><!-- --></div>
</div>
<?php include_once(_TEMPLATE_PATH . DS . 'css' . DS . 'footer.css.php') ?>
</center>
<script type="text/javascript" src="<?php echo _TEMPLATE_URL?>/func/jupiter.js"></script>
<!-- BJ Jupiter v1.7.1-->
</body>
</html>