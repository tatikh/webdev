<table class="adminheading">
		<tr>
			<th class="cpanel" rowspan="2" nowrap>BJ ImageSlider Management</th>
	  </tr>
	  </table>
    <table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminform">
	  <tr valign="top">
	    <td width="660">
	    <div id="cpanel">
	      <div style="float:left;">
	      <div class="icon">
  			<a href="index.php?option=com_bjimageslider&view=configuration">
  				<div class="iconimage">
  					<img src="<?php echo BJImageSlider_Path;?>assets/config.png" alt="Configuration" align="middle" name="image" border="0" /></div>
  				Configuration</a>
  		  </div>
  		  </div>
	      <div style="float:left;">
	      <div class="icon">
  			<a href="index.php?option=com_bjimageslider&view=categories">
  				<div class="iconimage">
  					<img src="<?php echo BJImageSlider_Path;?>assets/categories.png" alt="Manage categories" align="middle" name="image" border="0" /></div>
  				Manage Categories</a>
  		  </div>
  		  </div>
	      <div style="float:left;">
	      <div class="icon">
  			<a href="index.php?option=com_bjimageslider&view=photos">
  				<div class="iconimage">
  					<img src="<?php echo BJImageSlider_Path;?>assets/mediamanager.png" alt="Manage photos" align="middle" name="image" border="0" /></div>
  				Manage Photos</a>
  		  </div>
  		  </div>
	    </div>
	    </td>
	    <td>
	    </td>
	  </tr>
	  </table>