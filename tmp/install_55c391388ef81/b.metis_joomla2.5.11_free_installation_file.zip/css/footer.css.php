<div class="tips">
	<a href="http://byjoomla.com" title="Joomla BJ Metis template by ByJoomla.com"><strong>Joomla BJ Metis template by ByJoomla.com</strong></a>
</div>