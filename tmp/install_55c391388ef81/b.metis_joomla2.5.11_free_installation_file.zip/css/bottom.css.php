<div class="tl_foot">
<p>Copyright &copy; 2013 B. Metis. All Rights Reserved. Designed by <a href="http://byjoomla.com">ByJoomla.com</a><br>Joomla! is Free Software released under the GNU General Public License.</p>
</div>