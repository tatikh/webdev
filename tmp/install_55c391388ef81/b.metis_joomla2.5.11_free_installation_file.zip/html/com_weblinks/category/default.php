<?php defined('_JEXEC') or die('Restricted access');
$app =& JFactory::getApplication();
JLoader::register('JAddons', JPATH_THEMES.DS.$app->getTemplate().DS.'read_tpl_params.php');

$componentheading  = JAddons::getTplParams()->get('componentheading'); ?>
<?php if ( $this->params->def( 'show_page_title', 1 ) ) : ?>
	<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
		<span class="left"></span><?php echo "<" . $componentheading . ">" . $this->escape($this->params->get('page_title')) . "</" . $componentheading . ">"; ?><span class="right"></span>
	</div>
<?php endif; ?>

<table width="100%" cellpadding="4" cellspacing="0" border="0" align="center" class="contentpane<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
<?php if ( @$this->category->image || @$this->category->description ) : ?>
<tr>
	<td valign="top" class="contentdescription<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
	<?php
		if ( isset($this->category->image) ) :  echo $this->category->image; endif;
		echo $this->category->description;
	?>
	</td>
</tr>
<?php endif; ?>
<tr>
	<td width="60%" colspan="2">
	<?php echo $this->loadTemplate('items'); ?>
	</td>
</tr>
<?php if ($this->params->get('show_other_cats', 1)): ?>
<tr>
	<td width="60%" colspan="2">
		<ul>
		<?php foreach ( $this->categories as $category ) : ?>
			<li>
				<a href="<?php echo $category->link; ?>" class="category<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
					<?php echo $this->escape($category->title);?></a>
				&nbsp;
				<span class="small">
					(<?php echo $category->numlinks;?>)
				</span>
			</li>
		<?php endforeach; ?>
		</ul>
	</td>
</tr>
<?php endif; ?>
</table>
